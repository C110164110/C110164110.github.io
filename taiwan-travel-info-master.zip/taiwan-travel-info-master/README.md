- 專案描述
  - 使用交通部 OPEN API 實作台灣觀光介紹網站 [DEMO](https://f2e-2021-w1.vercel.app/home)

- 使用技術
  - Next.js

- 開放資料平台
  - [交通部運輸資料流通服務平臺(TDX) API](https://tdx.transportdata.tw/data-service/basic)

- 採用設計稿連結
  - [from 早餐](https://www.figma.com/file/5HQAZ2bunGNKma2fwU0aNZ/The-F2E-3rd---Week1-%E5%8F%B0%E7%81%A3%E6%97%85%E9%81%8A%E6%99%AF%E9%BB%9E%E5%B0%8E%E8%A6%BD?node-id=0%3A1)
