import React from 'react'
import styles from './index.module.scss'

const Footer = () => {
  return (
    <div className={styles.footer}>
      <div>#台灣旅遊景點導覽 #Breakfast</div>
    </div>
  )
}

export default Footer
