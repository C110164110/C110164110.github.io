exports.AppID = process.env.APP_ID
exports.AppKey = process.env.APP_KEY

exports.CLIENT_ID = process.env.CLIENT_ID
exports.CLIENT_SECRET = process.env.CLIENT_SECRET

exports.ENCODE_KEY = process.env.ENCODE_KEY
